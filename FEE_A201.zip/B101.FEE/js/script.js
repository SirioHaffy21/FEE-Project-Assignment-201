// validate email
function isEmail(input) {}

function isLength(input, minLength, maxLength) {
    if (input == null) {
        return false;
    }

    if (input.val().length > maxLength || input.val().length < minLength) {
        return false;
    }

    return true;
}

// validate checkbox
function isChecked(input) {
    if (input == null) {
        return false;
    }

    return input.checked;
}

function setText(input, message) {
    input.text(message);
}

// validate password
function isPassword(input) {}

// add class error to element
function addError(input) {
    input.classList.remove('text-success');

    input.classList.add('text-danger');
}

// add class success to element
function addSucces(input) {
    input.classList.remove('text-danger');

    input.classList.add('text-success');
}

function validateEmail(input) {
    const textError = input.siblings();

    if (!isLength(input, 5, 50)) {
        setText(textError, 'Length of email less than 50 character');

        addError(textError[0]);
    } else {
        setText(textError, 'Email is valid');

        addSucces(textError[0]);
    }
}

function validatePassword(input) {
    const textError = input.siblings();

    if (!isLength(input, 8, 30)) {
        setText(textError, 'Length of password less than 50 character');

        addError(textError[0]);
    } else {
        setText(textError, 'Password is valid');

        addSucces(textError[0]);
    }
}

function validateUsername(input) {
    const textError = input.siblings();

    if (!isLength(input, 3, 30)) {
        setText(textError, 'Length of username less than 50 character');

        addError(textError[0]);
    } else {
        setText(textError, 'Username is valid');

        addSucces(textError[0]);
    }
}

function validateRepassword(repassword, password) {
    const textError = repassword.siblings();
    debugger;
    if (!isLength(repassword, 8, 30)) {
        setText(textError, 'Length of re-password less than 50 character');

        addError(textError[0]);

        return;
    }

    if (repassword.val() != password.val()) {
        setText(textError, 'Re-password is not match');

        addError(textError[0]);

        return;
    }

    addSucces(textError[0]);
    setText(textError, 'Repassword is match');
}

function validateFirstName(input) {
    const textError = input.next();

    if (!isLength(input, 3, 30)) {
        setText(textError, 'Length of first name less than 50 character');

        debugger;

        addError(textError[0]);
    } else {
        setText(textError, 'First name is valid');

        addSucces(textError[0]);
    }
}

function validateLastName(input) {
    const textError = input.next();

    if (!isLength(input, 3, 30)) {
        setText(textError, 'Length of last name less than 50 character');

        addError(textError[0]);
    } else {
        setText(textError, 'Last name is valid');

        addSucces(textError[0]);
    }
}

function validateTitle(input) {
    const textError = input.next().first();

    if (!isLength(input, 10, 200)) {
        setText(textError, 'Length of title less than 50 character');

        addError(textError[0]);
    } else {
        setText(textError, 'Title is valid');

        addSucces(textError[0]);
    }
}

// login form
$('#loginButton').click(() => {
    const email = $('#email').first();
    const password = $('#password').first();

    validateEmail(email);

    validatePassword(password);
});

// register form
$('#registerButton').click(() => {
    const email = $('#email').first();
    const password = $('#password').first();
    const username = $('#username').first();
    const repassword = $('#repassword').first();

    validateEmail(email);

    validatePassword(password);

    validateUsername(username);

    validateRepassword(repassword, password);
});

// edit form
$('#editButton').click(() => {
    const firstname = $('#firstname').first();
    const lastname = $('#lastname').first();

    validateFirstName(firstname);

    validateLastName(lastname);
});

// add form
$('#addButton').click(() => {
    const title = $('#title').first();

    validateTitle(title);
});

// menu sidebar
$('#show-sidebar').click(() => {
    const maincontent = $('#maincontent');

    debugger;

    maincontent.toggleClass('active');
});

function funcRegister() {
    var userName = document.getElementById("username").innerHTML;
    var chkEmail = document.getElementById("email").innerHTML;
    var chkPassword = document.getElementById("password").innerHTML;
    var chkRePassword = document.getElementById("repassword").innerHTML;
    if (chkEmail.length < 3) {
        alert("length of email have to be between 5 and 50");
    } else if (chkPassword.length < 8 && chkPassword.length > 30) {
        alert("length of password have to be between 8 and 30");
    } else if (userName.length < 3 && userName.length > 30) {
        alert("length of user name have to be between 3 and 30");
    } else if (chkRePassword.length < 8 && chkRePassword.length > 30) {
        alert("length of password have to be between 8 and 30");
    } else {
        alert("success");
        window.location.href = "Bai1_P.A101_Login.html";
    }
}

function funcLogin() {
    // khai bao bien
    var chkEmail = document.getElementById("email").value;
    var chkPassword = document.getElementById("password").value;

    // check length
    if (chkEmail.length < 5 || chkEmail.length > 50) {
        alert("length of email have to be between 5 and 50");
    } else if (chkPassword.length < 8 || chkPassword.length > 30) {
        alert("length of password have to be between 8 and 30");

    } else {
        alert("success");
        window.location.href = "Bai1_P.A101_ViewContent.html";
    }
}